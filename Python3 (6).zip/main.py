import random

def get_user_feedback():
    while True:
        feedback = input("Як ви оцінюєте нашу допомогу (від 1 до 5): ")
        try:
            rating = int(feedback)
            if 1 <= rating <= 5:
                return rating
            else:
                print("Будь ласка, введіть число від 1 до 5.")
        except ValueError:
            print("Будь ласка, введіть число від 1 до 5.")

def suggest_activity(activities):
    choice = random.choice(activities)
    print(f"Ми рекомендуємо: {choice}")

def read_activities_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            activities = file.read().splitlines()
        return activities
    except FileNotFoundError:
        print("Файл не знайдено.")
        return []

def write_activity_to_file(activity, file_path):
    with open(file_path, 'a') as file:
        file.write(activity + '\n')

def main():
    mode = input("Натисніть 1, щоб запропонувати свої варіанти, або 2, щоб отримати пропозицію від програми: ")
    if mode == '1':
        user_activities = input("Запропонуйте свої варіанти діяльності, розділяючи їх комами: ").split(',')
        for activity in user_activities:
            write_activity_to_file(activity.strip(), 'activities.txt')
        suggest_activity(user_activities)
    elif mode == '2':
        activities = read_activities_from_file('activities.txt')
        if not activities:
            activities = ["Прочитати книгу", "Подивитися фільм", "Прогулянка", "Зайнятися спортом", "Приготувати нову страву"]
        input("Натисніть Enter, щоб отримати рекомендацію... ")
        suggest_activity(activities)
    else:
        print("Невірний вибір. Спробуйте ще раз.")
        main()
    
    rating = get_user_feedback()
    print(f"Дякуємо за вашу оцінку: {rating}/5")

if __name__ == "__main__":
    main()